import './App.css';
import image1 from './1.png';
import image2 from './2.png';
import image3 from './3.png';
import logo from './logo.png'

function App() {
  return (
    <div>
  <div class="flexpropertycontainer">
    <div>
      <img src={image1} alt="1" style={{height: '560px', width: '75%', paddingTop: '22%' }} />
    </div>
    <div>
      <img src={logo} alt="logo" style={{ height: '100px'}} />
      <h5><strong> C.R.I. PUMPS WINS THE NATIONAL ENERGY CONSERVATION AWARD 2018 for the 4th time.</strong></h5>
      <ul>
        <li> C.R.I.'s energy efficient products are well recognized by various Government Institutions, as trustworthy
          products for various projects across the globe to save energy.</li>
        <li>C.R.I. is the highest contributor in the country for the projects of EESL (Energy Efficiency Services
          Limited) to replace the old inefficient pumps with 5 Star rated energy efficient smart pumps with IoT enabled
          control panel. </li>
      </ul>
      <img src={image2} alt="2"/>
      <h5>Government of India has awarded the <strong>"National Energy Conservation Award 2018"</strong>. Mr. G.
        Selvaraj, Joint Managing Director of C.R.I. Group received the award from Smt. Sumitra Mahajan, Speaker of Lok
        Sabha & Shri. Raj Kumar Singh, Honorable Minister of State.</h5>
    </div>
  </div>

  <h5>INSTALLED OVER 10 LAKHS STAR RATED PUMPSETS ACROSS THE COUNTRY RESULTING IN A CUMULATIVE SAVING OF MORE THAN 9,000
    MILLION UNITS OF POWER FOR THE NATION. </h5>

  <div class="con">
    <img src={image3} alt="3" />
    <h5>Valves - Pumps - Pipes - IoT Drives & Controllers - Wires & Cables - Solar Systems - Motors </h5>
    <hr style={{ backgroundColor: 'red', height: '2px'}} />
  </div>

  <h5 style={{fontSize: '15px'}}>
    <bold>C.R.I. FLUID SYSTEMS PRODUCTS CATER TO DIVERSE SEGMENTS</bold>
  </h5>
  <h5>CHEMICALS & PROCESS POWER WATER & WASTE WATER OILS & GAS PHARMA SUGARS & DISTILLERIES PAPER & PULP MARINE &
    DEFENCE METAL & MINING FOOD & BEVERAGE PETROCHEMICAL & REFINERIES SOLAR BUILDING HVAC FIRE FIGHTING AGRICULTURE &
    RESIDENTIAL</h5>
  <div class="fot">
    <i class="fa fa-phone-square " aria-hidden="true">Toll free:1800 200 1234</i>
    <i class="fa fa-facebook-official" aria-hidden="true">www.facebook.com/cripumps</i>
    <i class="fa fa-globe" aria-hidden="true">www.crigroups.com</i>
  </div>
</div>
);
}

export default App;
